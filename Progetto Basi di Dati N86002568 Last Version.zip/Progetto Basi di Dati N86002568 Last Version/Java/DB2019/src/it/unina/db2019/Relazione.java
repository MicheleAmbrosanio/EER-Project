/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unina.db2019;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author a
 */
public class Relazione extends DBFrame {

    int idSchema; 
    String nomeSchema;
    Schema schema;
   
    /**
     * Creates new form Relazione
     */
    public Relazione(int idSchema, String nomeSchema, Schema schema) {
        this.schema = schema;
        this.idSchema = idSchema;
        this.nomeSchema = nomeSchema;
        initComponents();
        setModalita(APPEND_QUERY);
        setFrameTable(jTableRelazione);
        setNomeTabella("relazione");
        super.setColorTextField(jTextFieldNomeRelazione);
        setTitle(nomeSchema + " > " + "RELAZIONE");
    }

    private Relazione() {
        initComponents();
    }

    @Override
   final public void setModalita(int modo) {
      super.setModalita(modo);
      switch (modo) {
         case APPEND_QUERY:
            jTextFieldNomeRelazione.setEnabled(true);
            jComboBoxGrado.setEnabled(true);
            break;
         case BROWSE:
            jTextFieldNomeRelazione.setEnabled(false);
            jComboBoxGrado.setEnabled(false);
            break;
         case UPDATE:
            jTextFieldNomeRelazione.setEnabled(true);
            jComboBoxGrado.setEnabled(true);
            break;
      }
   }
   
   /**
    * Mostra una descrizione di un errore SQL in un linguaggio comprensibile per
    * l'utente finale.
    * 
    * @param e eccezione SQLException catturata
    * @param query l'istruzione SQL che ha causato l'errore
    * @param contesto intero per distinguere se l'eccezione ha avuto origine
    * da una query
    */
   @Override
   protected void mostraErrori(SQLException e, String query, int contesto) {
      String msg;
      if (e.getErrorCode() == 1) {
         msg = "Esiste già una relazione con lo stesso codice";
         JOptionPane.showMessageDialog(this, msg, "Errore",
                 JOptionPane.ERROR_MESSAGE);
      } else {
         super.mostraErrori(e, query, contesto);
      }
   }
   
   /**
    * Metodo da usare nei form di lookup per passare i dati al form
    * chiamante.
    */
   @Override
   protected void premutoOK() {
      if (getPadre() != null) {
         getPadre().setProprieta("Relazione", getTCodice().getText());
         try {
            rs.close();
         } catch (SQLException e) {
            mostraErrori(e);
         }
         dispose();
      }
   }
   
   /**
    * Ricopia i dati della riga selezionata del JTable
    * sugli altri controlli della finestra.
    */
   @Override
   protected void mostraDati() {
      try {
         rs.previous(); rs.next();
         jTextFieldNomeRelazione.setText(rs.getString("nome_relazione"));
         jComboBoxGrado.setSelectedItem(rs.getString("grado"));
         super.mostraDati();
      } catch (SQLException e) {
//         mostraErrori(e);
      }
   }
   
   /**
    * Cancella i dati presenti in tutti i controlli presenti sul form.
    */
   @Override
   protected void pulisci() {
      super.pulisci();
      jTextFieldNomeRelazione.setText("");
      jComboBoxGrado.setSelectedItem("0"); 
   }
   
   /**
    * Forma una query corrispondente ai dati inseriti nei
    * controlli della finestra.
    * 
    * @return query, come {@link PreparedStatement}
    */
   @Override
   protected PreparedStatement creaSelectStatement() {
      Connection con;
      PreparedStatement st;
      String codice, nomeR, grado;
      Pattern pat;
      Matcher matc;
      int k = 1;
      super.creaSelectStatement();
      codice = getTCodice().getText();
      nomeR = jTextFieldNomeRelazione.getText();
      grado = jComboBoxGrado.getSelectedItem().toString();

      query += " where";
      //}
      if (String.valueOf(idSchema).length() > 0) {
         query += " id_schema= ? and";
      }
      
      if (codice.length() > 0) {
         query += " codice= ? and";
      }
      if (nomeR.length() > 0) {
         if (nomeR.contains("%")) {
            query += " nome_relazione like ? and";
         } else {
            query += " nome_relazione = ? and";
         }
      }
      if (grado.length() > 0) {
         if (grado.contains("%")) {
            query += " grado like ? and";
         } else {
            query += " grado = ? and";
         }
      }
      pat = Pattern.compile("where$|and$"); //cancella where o and finali
      matc = pat.matcher(query);
      query = matc.replaceAll("");
      query += " order by codice";
      try {
         con = Database.getDefaultConnection();
         st = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);

         if (String.valueOf(idSchema).length() > 0) {
            st.setInt(k++, idSchema);
         }
         if (codice.length() > 0) {
            st.setInt(k++, Integer.decode(codice));
         }
         if (nomeR.length() > 0) {
            st.setString(k++, nomeR);
         }
         if (grado.length() > 0) {
            st.setString(k++, grado);
         }
         return st;
      } catch (SQLException e) {
         mostraErrori(e);
         return null;
      }
   }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldNomeRelazione = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableRelazione = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jComboBoxGrado = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(500, 200));

        jLabel1.setText("Nome Relazione");

        jTableRelazione.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTableRelazione);

        jLabel2.setText("Ricerca Grado");

        jComboBoxGrado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "2", "4" }));
        jComboBoxGrado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxGradoActionPerformed(evt);
            }
        });

        jButton1.setText("Indietro");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Associa Relazione a Entità");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jTextFieldNomeRelazione, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBoxGrado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxGrado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldNomeRelazione)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            dispose();
            this.schema.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        AssociareER ass = new AssociareER(idSchema, nomeSchema, this);
        ass.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBoxGradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxGradoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxGradoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Relazione.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Relazione.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Relazione.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Relazione.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Relazione().setVisible(true);
            }
        });
    }

    @Override
   protected PreparedStatement getComandoInserimento(Connection c)
           throws SQLException {
      String cmdIns;
      PreparedStatement st;
      cmdIns = "insert into " + Database.schema + ".relazione (codice,nome_relazione,"
              + "grado, id_schema) values(?,?,?,?)";
      st = c.prepareStatement(cmdIns);
      st.setInt(1, 0);
      st.setString(2, jTextFieldNomeRelazione.getText());
      st.setInt(3, 0);
      st.setString(4, String.valueOf(idSchema));
      return st;
   }

    /**
    * Prepara il comando SQL di aggiornamento in base ai dati
    * inseriti nei controlli.
    * 
    * @param c la connessione al DB
    * @return il comando, come {@link PreparedStatement}
    * @throws SQLException in caso di errori nel preparare il
    * comando
    */
   @Override
   protected PreparedStatement getComandoAggiornamento(Connection c)
           throws SQLException {
      String cmdUp;
      PreparedStatement st;
      cmdUp = "update " + Database.schema + ".relazione set nome_relazione=?,grado=? "
              + "where codice=? and id_schema=?";
      st = c.prepareStatement(cmdUp);
      st.setString(1, jTextFieldNomeRelazione.getText());
      st.setInt(2, 0);
      st.setInt(3, Integer.decode(getTCodice().getText()));
      st.setString(4, String.valueOf(idSchema));
      return st;
   }
   
   protected void disposeCurrentPanel() {
        dispose();
    }
   
   protected void impostaCodice() {
   }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBoxGrado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableRelazione;
    private javax.swing.JTextField jTextFieldNomeRelazione;
    // End of variables declaration//GEN-END:variables
}
