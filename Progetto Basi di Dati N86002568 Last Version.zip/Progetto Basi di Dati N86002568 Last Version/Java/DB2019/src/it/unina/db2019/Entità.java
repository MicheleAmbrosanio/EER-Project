/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unina.db2019;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author a
 */
public class Entità extends DBFrame {
    
    int idSchema; 
    String nomeSchema;
    Schema schema;
    

    /**
     * Creates new form Entità
     */
    public Entità(int idSchema, String nomeSchema, Schema schema) {
        this.schema = schema;
        this.idSchema = idSchema;
        this.nomeSchema = nomeSchema;
        initComponents();
        setModalita(APPEND_QUERY);
        setFrameTable(jTableEntità);
        setNomeTabella("entita");
        super.setColorTextField(jTextFieldNome);
        jComboBoxTipo.setBorder(new LineBorder(Color.RED));
        setTitle(nomeSchema + " > " + "ENTITA'");
       
        jComboBoxTipo.addActionListener (new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent ae) {
                if(jComboBoxTipo.getSelectedItem().toString() != "NESSUNA"){
                    jComboBoxTipo.setBorder(new LineBorder(Color.WHITE));
                }else
                    jComboBoxTipo.setBorder(new LineBorder(Color.RED));
            }
        });
    }

    private Entità() {
        initComponents();
    }
   
    
    /**
    * Imposta lo stato corrente del form. <br> In base allo stato vengono
    * abilitati o disabilitati alcuni oggetti del form.
    * 
    * @param modo intero che rappresenta lo stato
    */
   @Override
   final public void setModalita(int modo) {
      super.setModalita(modo);
      switch (modo) {
         case APPEND_QUERY:
            jTextFieldNome.setEnabled(true);
            jComboBoxTipo.setEnabled(true);
            break;
         case BROWSE:
            jTextFieldNome.setEnabled(false);
            jComboBoxTipo.setEnabled(false);
            break;
         case UPDATE:
            jTextFieldNome.setEnabled(true);
            jComboBoxTipo.setEnabled(true);
            break;
      }
   }
   
   /**
    * Mostra una descrizione di un errore SQL in un linguaggio comprensibile per
    * l'utente finale.
    * 
    * @param e eccezione SQLException catturata
    * @param query l'istruzione SQL che ha causato l'errore
    * @param contesto intero per distinguere se l'eccezione ha avuto origine
    * da una query
    */
   @Override
   protected void mostraErrori(SQLException e, String query, int contesto) {
      String msg;
      if (e.getErrorCode() == 1) {
         msg = "Esiste già un'entita con lo stesso codice";
         JOptionPane.showMessageDialog(this, msg, "Errore",
                 JOptionPane.ERROR_MESSAGE);
      } else {
         super.mostraErrori(e, query, contesto);
      }
   }
   
   /**
    * Metodo da usare nei form di lookup per passare i dati al form
    * chiamante.
    */
   @Override
   protected void premutoOK() {
      if (getPadre() != null) {
         getPadre().setProprieta("Entita", getTCodice().getText());
         try {
            rs.close();
         } catch (SQLException e) {
            mostraErrori(e);
         }
         dispose();
      }
   }
   
   
   /**
    * Ricopia i dati della riga selezionata del JTable
    * sugli altri controlli della finestra.
    */
   @Override
   protected void mostraDati() {
      try {
         rs.previous(); rs.next();
         jTextFieldNome.setText(rs.getString("nome_entita"));
         jComboBoxTipo.setSelectedItem(rs.getString("tipo"));
         super.mostraDati();
      } catch (SQLException e) {
//         mostraErrori(e);
      }
   }
   
   /**
    * Cancella i dati presenti in tutti i controlli presenti sul form.
    */
   @Override
   protected void pulisci() {
      super.pulisci();
      jTextFieldNome.setText("");
      jComboBoxTipo.setSelectedItem("NESSUNA");
   }
   
   /**
    * Forma una query corrispondente ai dati inseriti nei
    * controlli della finestra.
    * 
    * @return query, come {@link PreparedStatement}
    */
   @Override
   protected PreparedStatement creaSelectStatement() {
      Connection con;
      PreparedStatement st;
      String codice, tipo, nome;
      Pattern pat;
      Matcher matc;
      int k = 1;
      super.creaSelectStatement();
      codice = getTCodice().getText();
      tipo = jComboBoxTipo.getSelectedItem().toString();
      nome = jTextFieldNome.getText();

      query += " where";
      //}
      if (String.valueOf(idSchema).length() > 0) {
         query += " id_schema= ? and";
      }
      
      if (codice.length() > 0) {
         query += " codice= ? and";
      }
      if (tipo.length() > 0 && !tipo.equals("NESSUNA")) {
         if (tipo.contains("%")) {
            query += " tipo like ? and";
         } else {
            query += " tipo = ? and";
         }
      }
      if (nome.length() > 0) {
         if (nome.contains("%")) {
            query += " nome_entita like ?";
         } else {
            query += " nome_entita = ?";
         }
      }
      pat = Pattern.compile("where$|and$"); //cancella where o and finali
      matc = pat.matcher(query);
      query = matc.replaceAll("");
      query += " order by codice";
      try {
         con = Database.getDefaultConnection();
         st = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);

         if (String.valueOf(idSchema).length() > 0) {
            st.setInt(k++, idSchema);
         }
         if (codice.length() > 0) {
            st.setInt(k++, Integer.decode(codice));
         }
         if (tipo.length() > 0 && !tipo.equals("NESSUNA")) {
            st.setString(k++, tipo);
         }
         if (nome.length() > 0) {
            st.setString(k++, nome);
         }
         return st;
      } catch (SQLException e) {
         mostraErrori(e);
         return null;
      }
   }
   
   protected void impostaCodice() {
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEntità = new javax.swing.JTable();
        jTextFieldNome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBoxTipo = new javax.swing.JComboBox<>();
        jButtonAttributi = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestione Entità");
        setLocation(new java.awt.Point(500, 200));

        jTableEntità.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableEntità);

        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });

        jLabel1.setText("Nome");

        jLabel2.setText("Tipo");

        jComboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "FORTE", "DEBOLE" }));
        jComboBoxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoActionPerformed(evt);
            }
        });

        jButtonAttributi.setText("Gestisci Attributi");
        jButtonAttributi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAttributiActionPerformed(evt);
            }
        });

        jButton1.setText("Aggiungi Superclasse");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jToggleButton1.setText("Indietro");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButtonAttributi, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(27, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jComboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 202, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jToggleButton1))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton1)))))
                .addContainerGap(29, Short.MAX_VALUE))
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jToggleButton1)
                        .addGap(25, 25, 25)))
                .addComponent(jButton1)
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jButtonAttributi)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoActionPerformed

    private void jButtonAttributiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAttributiActionPerformed
        if(jTableEntità.getSelectedRow() < 0)
            JOptionPane.showMessageDialog(new JFrame(), "IMPOSSIBILE CLICCARE IL PULSANTE. SELEZIONARE UN'ENTITA'", "ERRORE",
        JOptionPane.ERROR_MESSAGE);
        int columnIdEntità = 0;
        int columnNomeEntità = 1;
        int row = jTableEntità.getSelectedRow();
        String idEntità = jTableEntità.getModel().getValueAt(row, columnIdEntità).toString();
        String nomeEntità = jTableEntità.getModel().getValueAt(row, columnNomeEntità).toString();
        this.setVisible(false);
        Attributo e = new Attributo(Integer.parseInt(idEntità), nomeEntità, nomeSchema, this);
        e.setVisible(true);
        
    }//GEN-LAST:event_jButtonAttributiActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(jTableEntità.getSelectedRow() < 0)
            JOptionPane.showMessageDialog(new JFrame(), "IMPOSSIBILE CLICCARE IL PULSANTE. SELEZIONARE UN'ENTITA'", "ERRORE",
        JOptionPane.ERROR_MESSAGE);
        int columnIdEntità = 0;
        int columnNomeEntità = 1;
        int row = jTableEntità.getSelectedRow();
        String idEntità = jTableEntità.getModel().getValueAt(row, columnIdEntità).toString();
        String nomeEntità = jTableEntità.getModel().getValueAt(row, columnNomeEntità).toString();
        Map<String, Integer> res = Database.getAllEntità(this.idSchema, idEntità);
        this.setVisible(false);
        Ereditarietà er = new Ereditarietà(idSchema, nomeSchema, idEntità, nomeEntità, res, this);
        er.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        dispose();
        this.schema.setVisible(true);
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldNomeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Entità.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Entità.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Entità.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Entità.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Entità().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAttributi;
    private javax.swing.JComboBox<String> jComboBoxTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableEntità;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables

    @Override
   protected PreparedStatement getComandoInserimento(Connection c)
           throws SQLException {
      String cmdIns;
      PreparedStatement st;
      cmdIns = "insert into " + Database.schema + ".entita (codice,nome_entita,"
              + "tipo, id_schema) values(?,?,?,?)";
      st = c.prepareStatement(cmdIns);
      st.setInt(1, 0);
      st.setString(2, jTextFieldNome.getText());
      st.setString(3, jComboBoxTipo.getSelectedItem().toString());
      st.setString(4, String.valueOf(idSchema));
      return st;
   }

    /**
    * Prepara il comando SQL di aggiornamento in base ai dati
    * inseriti nei controlli.
    * 
    * @param c la connessione al DB
    * @return il comando, come {@link PreparedStatement}
    * @throws SQLException in caso di errori nel preparare il
    * comando
    */
   @Override
   protected PreparedStatement getComandoAggiornamento(Connection c)
           throws SQLException {
      String cmdUp;
      PreparedStatement st;
      cmdUp = "update " + Database.schema + ".entita set nome_entita=?,tipo=? "
              + "where codice=? and id_schema=?";
      st = c.prepareStatement(cmdUp);
      st.setString(1, jTextFieldNome.getText());
      st.setString(2, jComboBoxTipo.getSelectedItem().toString());
      st.setInt(3, Integer.decode(getTCodice().getText()));
      st.setString(4, String.valueOf(idSchema));
      return st;
   }
   
   protected void disposeCurrentPanel() {
        dispose();
    }
}
