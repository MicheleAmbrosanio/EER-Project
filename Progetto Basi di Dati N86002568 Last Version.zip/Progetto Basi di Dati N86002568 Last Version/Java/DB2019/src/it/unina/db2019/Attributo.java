/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unina.db2019;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author a
 */
public class Attributo extends DBFrame {

    int idEntità;
    String nomeEntità;
    String nomeSchema;
    Entità entità;
    /**
     * Creates new form Attributo
     */
    public Attributo(int idEntità, String nomeEntità, String nomeSchema, Entità entità) {
        this.idEntità = idEntità;
        this.entità = entità;
        this.nomeEntità = nomeEntità;
        this.nomeSchema = nomeSchema;
        initComponents();
        setModalita(APPEND_QUERY);
        setFrameTable(jTableAttributo);
        setNomeTabella("attributo");
        super.setColorTextField(jTextFieldNome);
        jComboBoxVisibilità.setBorder(new LineBorder(Color.red));
        jComboBoxTipoDato.setBorder(new LineBorder(Color.red));
        jComboBoxStruttura.setBorder(new LineBorder(Color.red));
        setTitle(nomeSchema + ">" + nomeEntità + ">" + "ATTRIBUTO" );
        
        this.jComboBoxVisibilità.addActionListener (new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent ae) {
                if(jComboBoxVisibilità.getSelectedItem().toString() != "NESSUNA"){
                    jComboBoxVisibilità.setBorder(new LineBorder(Color.white));
                }else
                    jComboBoxVisibilità.setBorder(new LineBorder(Color.red));
            }
        });
        
        jComboBoxTipoDato.addActionListener (new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent ae) {
                if(jComboBoxTipoDato.getSelectedItem().toString() != "NESSUNA"){
                    jComboBoxTipoDato.setBorder(new LineBorder(Color.white));
                }else
                    jComboBoxTipoDato.setBorder(new LineBorder(Color.red));
            }
        });
        
        jComboBoxStruttura.addActionListener (new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent ae) {
                if(jComboBoxStruttura.getSelectedItem().toString() != "NESSUNA"){
                    jComboBoxStruttura.setBorder(new LineBorder(Color.white));
                }else
                    jComboBoxStruttura.setBorder(new LineBorder(Color.red));
            }
        });
    }
    

    private Attributo() {
        initComponents();
    }
    
    /**
    * Imposta lo stato corrente del form. <br> In base allo stato vengono
    * abilitati o disabilitati alcuni oggetti del form.
    * 
    * @param modo intero che rappresenta lo stato
    */
   @Override
   final public void setModalita(int modo) {
      super.setModalita(modo);
      switch (modo) {
         case APPEND_QUERY:
            jTextFieldNome.setEnabled(true);
            jComboBoxVisibilità.setEnabled(true);
            jComboBoxTipoDato.setEnabled(true);
            jComboBoxStruttura.setEnabled(true);
            jComboBoxTipoChiave.setEnabled(true);
            
            break;
         case BROWSE:
            jTextFieldNome.setEnabled(false);
            jComboBoxVisibilità.setEnabled(false);
            jComboBoxTipoDato.setEnabled(false);
            jComboBoxStruttura.setEnabled(false);
            jComboBoxTipoChiave.setEnabled(false);
            
            break;
         case UPDATE:
            jTextFieldNome.setEnabled(true);
            jComboBoxVisibilità.setEnabled(true);
            jComboBoxTipoDato.setEnabled(true);
            jComboBoxStruttura.setEnabled(true);
            jComboBoxTipoChiave.setEnabled(true);
            
            break;
      }
   }
   
   /**
    * Mostra una descrizione di un errore SQL in un linguaggio comprensibile per
    * l'utente finale.
    * 
    * @param e eccezione SQLException catturata
    * @param query l'istruzione SQL che ha causato l'errore
    * @param contesto intero per distinguere se l'eccezione ha avuto origine
    * da una query
    */
   @Override
   protected void mostraErrori(SQLException e, String query, int contesto) {
      String msg;
      if (e.getErrorCode() == 1) {
         msg = "Esiste già un attributo con lo stesso codice";
         JOptionPane.showMessageDialog(this, msg, "Errore",
                 JOptionPane.ERROR_MESSAGE);
      } else {
         super.mostraErrori(e, query, contesto);
      }
   }
   
   /**
    * Metodo da usare nei form di lookup per passare i dati al form
    * chiamante.
    */
   @Override
   protected void premutoOK() {
      if (getPadre() != null) {
         getPadre().setProprieta("Attributo", getTCodice().getText());
         try {
            rs.close();
         } catch (SQLException e) {
            mostraErrori(e);
         }
         dispose();
      }
   }
   
   /**
    * Ricopia i dati della riga selezionata del JTable
    * sugli altri controlli della finestra.
    */
   @Override
   protected void mostraDati() {
      try {
         rs.previous(); rs.next();

         jTextFieldNome.setText(rs.getString("nome_attributo"));
         jComboBoxVisibilità.setSelectedItem(rs.getString("visibilita"));
         jComboBoxTipoDato.setSelectedItem(rs.getString("tipo_dato"));
         jComboBoxStruttura.setSelectedItem(rs.getString("struttura"));
         jComboBoxTipoChiave.setSelectedItem(rs.getString("tipo_chiave"));
         super.mostraDati();
      } catch (SQLException e) {
//          mostraErrori(e);
      }
   }
   
   /**
    * Cancella i dati presenti in tutti i controlli presenti sul form.
    */
   @Override
   protected void pulisci() {
      super.pulisci();
      jTextFieldNome.setText("");
      jComboBoxVisibilità.setSelectedItem("NESSUNA");
      jComboBoxTipoDato.setSelectedItem("NESSUNA");
      jComboBoxStruttura.setSelectedItem("NESSUNA");
      jComboBoxTipoChiave.setSelectedItem("NESSUNA");
   }
   
   /**
    * Forma una query corrispondente ai dati inseriti nei
    * controlli della finestra.
    * 
    * @return query, come {@link PreparedStatement}
    */
   @Override
   protected PreparedStatement creaSelectStatement() {
      Connection con;
      PreparedStatement st = null;
      String codice, nome, vis, tipo, str, tipoc;
      Pattern pat;
      Matcher matc;
      int k = 1;
      super.creaSelectStatement();
      codice = getTCodice().getText();
      nome = jTextFieldNome.getText();
      vis = jComboBoxVisibilità.getSelectedItem().toString();
      tipo = jComboBoxTipoDato.getSelectedItem().toString();
      str = jComboBoxStruttura.getSelectedItem().toString();
      tipoc = jComboBoxTipoChiave.getSelectedItem().toString();

      query += " where";
      //}
      if (String.valueOf(idEntità).length() > 0) {
         query += " id_entita= ? and";
      }
      if (codice.length() > 0) {
         query += " codice= ? and";
      }
      if (nome.length() > 0) {
         if (nome.contains("%")) {
            query += " nome_attributo like ? and";
         } else {
            query += " nome_attributo = ? and";
         }
      }
      if (vis.length() > 0 && !vis.equals("NESSUNA")) {
         if (vis.contains("%")) {
            query += " visibilita like ? and";
         } else {
            query += " visibilita = ? and";
         }
      }
      if (tipo.length() > 0 && !tipo.equals("NESSUNA")) {
         if (tipo.contains("%")) {
            query += " tipo_dato like ? and";
         } else {
            query += " tipo_dato = ? and";
         }
      }
      if (str.length() > 0 && !str.equals("NESSUNA")) {
         if (str.contains("%")) {
            query += " struttura like ? and";
         } else {
            query += " struttura = ? and";
         }
      }
      if (tipoc.length() > 0 && !tipoc.equals("NESSUNA")) {
         if (str.contains("%")) {
            query += " tipo_chiave like ? and";
         } else {
            query += " tipo_chiave = ? and";
         }
      }
      pat = Pattern.compile("where$|and$"); //cancella where o and finali
      matc = pat.matcher(query);
      query = matc.replaceAll("");
      query+=" order by codice";
      try {
         con = Database.getDefaultConnection();
         st = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);

         if(String.valueOf(idEntità).length() > 0){
             st.setInt(k++, idEntità);
         }
         if (codice.length() > 0) {
            st.setInt(k++, Integer.decode(codice));
         }
         if (nome.length() > 0) {
            st.setString(k++, nome);
         }
         if (vis.length() > 0 && !vis.equals("NESSUNA")) {
            st.setString(k++, vis);
         }
         if (tipo.length() > 0 && !tipo.equals("NESSUNA")) {
            st.setString(k++, tipo);
         }
         if (str.length() > 0 && !str.equals("NESSUNA")) {
            st.setString(k++, str);
         }
         if (tipoc.length() > 0 && !tipoc.equals("NESSUNA")) {
            st.setString(k++, tipoc);
         }
      } catch (SQLException e) {
         //mostraErrori(e);
         //return null;
      }
      
      return st;
   }
   
   protected void impostaCodice() {
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jComboBoxVisibilità = new javax.swing.JComboBox<>();
        jComboBoxTipoDato = new javax.swing.JComboBox<>();
        jComboBoxStruttura = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableAttributo = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jComboBoxTipoChiave = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestione Attributo");
        setLocation(new java.awt.Point(500, 200));

        jLabel1.setText("Nome");

        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });

        jComboBoxVisibilità.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "PUBLIC", "PROTECTED", "PRIVATE" }));
        jComboBoxVisibilità.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxVisibilitàActionPerformed(evt);
            }
        });

        jComboBoxTipoDato.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "STRINGA", "VARCHAR2", "INTEGER", "BOOLEAN", "DATE", "TIMESTAMP" }));
        jComboBoxTipoDato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoDatoActionPerformed(evt);
            }
        });

        jComboBoxStruttura.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "SEMPLICE", "COMPOSTO" }));

        jLabel2.setText("Visibilità");

        jLabel3.setText("Tipo Dato");

        jLabel4.setText("Struttura");

        jTableAttributo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTableAttributo);

        jButton1.setText("Indietro");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setText("Tipo Chiave");

        jComboBoxTipoChiave.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "INTERNA" }));
        jComboBoxTipoChiave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoChiaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBoxTipoDato, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldNome, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxVisibilità, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboBoxStruttura, 0, 113, Short.MAX_VALUE)
                                    .addComponent(jComboBoxTipoChiave, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(90, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBoxStruttura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxVisibilità, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(jComboBoxTipoChiave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxTipoDato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxVisibilitàActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxVisibilitàActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxVisibilitàActionPerformed

    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldNomeActionPerformed

    private void jComboBoxTipoDatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoDatoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoDatoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        this.entità.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBoxTipoChiaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoChiaveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoChiaveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Attributo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Attributo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Attributo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Attributo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Attributo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBoxStruttura;
    private javax.swing.JComboBox<String> jComboBoxTipoChiave;
    private javax.swing.JComboBox<String> jComboBoxTipoDato;
    private javax.swing.JComboBox<String> jComboBoxVisibilità;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableAttributo;
    private javax.swing.JTextField jTextFieldNome;
    // End of variables declaration//GEN-END:variables

    @Override
   protected PreparedStatement getComandoInserimento(Connection c)
           throws SQLException {
      String cmdIns;
      PreparedStatement st;
      cmdIns = "insert into " + Database.schema + ".attributo (codice,nome_attributo,"
              + "visibilita, tipo_dato, struttura, id_entita, tipo_chiave) values(?,?,?,?,?,?,?)";
      st = c.prepareStatement(cmdIns);
      st.setInt(1, 0);
      st.setString(2, jTextFieldNome.getText());
      st.setString(3, jComboBoxVisibilità.getSelectedItem().toString());
      st.setString(4, jComboBoxTipoDato.getSelectedItem().toString());
      st.setString(5, jComboBoxStruttura.getSelectedItem().toString());
      st.setString(6, String.valueOf(idEntità));
      st.setString(7, jComboBoxTipoChiave.getSelectedItem().toString());
      return st;
   }

    /**
    * Prepara il comando SQL di aggiornamento in base ai dati
    * inseriti nei controlli.
    * 
    * @param c la connessione al DB
    * @return il comando, come {@link PreparedStatement}
    * @throws SQLException in caso di errori nel preparare il
    * comando
    */
   @Override
   protected PreparedStatement getComandoAggiornamento(Connection c)
           throws SQLException {
      String cmdUp;
      PreparedStatement st;
      cmdUp = "update " + Database.schema + ".attributo set nome_attributo=?, visibilita=?, tipo_dato=?, struttura=?, tipo_chiave=? "
              + "where codice=? and id_entita=?";
      st = c.prepareStatement(cmdUp);
      
      st.setString(1, jTextFieldNome.getText());
      st.setString(2, jComboBoxVisibilità.getSelectedItem().toString());
      st.setString(3, jComboBoxTipoDato.getSelectedItem().toString());
      st.setString(4, jComboBoxStruttura.getSelectedItem().toString());
      st.setString(5, jComboBoxTipoChiave.getSelectedItem().toString());
      st.setInt(6, Integer.decode(getTCodice().getText()));
      st.setString(7, String.valueOf(idEntità));
      
      return st;
   }
    
    protected void disposeCurrentPanel() {
        dispose();
    }
}

