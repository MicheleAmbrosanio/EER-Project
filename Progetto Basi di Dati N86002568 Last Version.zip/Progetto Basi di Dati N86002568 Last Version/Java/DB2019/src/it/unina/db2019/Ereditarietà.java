/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unina.db2019;

import static it.unina.db2019.DBFrame.APPEND_QUERY;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author a
 */
public class Ereditarietà extends DBFrame {

    int idSchema;
    String nomeSchema;
    String idEntità;
    String nomeEntità;
    Entità entità;
    Map<String, Integer> mapEntità;
    
    /**
     * Creates new form Ereditarietà
     */
    private Ereditarietà() {
        initComponents();
    }

    public Ereditarietà(int idSchema, String nomeSchema, String idEntità, String nomeEntità, Map<String, Integer> res, Entità entità) {
        this.idSchema = idSchema;
        this.entità = entità;
        this.nomeSchema = nomeSchema;
        this.idEntità = idEntità;
        this.nomeEntità = nomeEntità;
        this.nomeSchema = nomeSchema;
        this.mapEntità = res;
        initComponents();
        setModalita(APPEND_QUERY);
        setFrameTable(jTableEreditarietà);
        setNomeTabella("ereditare_entita_entita"); // TODO: nome tabella
        setTitle(nomeSchema + ">" + nomeEntità + ">" + "EREDITARIETA'");
        jComboBoxTipo.setBorder(new LineBorder(Color.RED));
        jComboBoxCardinalità.setBorder(new LineBorder(Color.RED));
        this.addItemCombo(res);
        
        jComboBoxTipo.addActionListener (new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent ae) {
                if(jComboBoxTipo.getSelectedItem().toString() != "NESSUNA"){
                    jComboBoxTipo.setBorder(new LineBorder(Color.WHITE));
                }else
                    jComboBoxTipo.setBorder(new LineBorder(Color.RED));
            }
        });
        
        jComboBoxCardinalità.addActionListener (new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent ae) {
                if(jComboBoxCardinalità.getSelectedItem().toString() != "NESSUNA"){
                    jComboBoxCardinalità.setBorder(new LineBorder(Color.WHITE));
                }else
                    jComboBoxCardinalità.setBorder(new LineBorder(Color.RED));
            }
        });
    }
    
    @Override
   final public void setModalita(int modo) {
      super.setModalita(modo);
      switch (modo) {
         case APPEND_QUERY:
            jComboBoxTipo.setEnabled(true);
            jComboBoxSuperclasse.setEnabled(true);
            jComboBoxCardinalità.setEnabled(true);
            
            break;
         case BROWSE:
            jComboBoxTipo.setEnabled(false);
            jComboBoxSuperclasse.setEnabled(false);
            jComboBoxCardinalità.setEnabled(false);
            
            break;
         case UPDATE:
            jComboBoxTipo.setEnabled(true);
            jComboBoxSuperclasse.setEnabled(true);
            jComboBoxCardinalità.setEnabled(true);
            
            break;
      }
   }
   
   @Override
   protected void mostraErrori(SQLException e, String query, int contesto) {
      String msg;
      if (e.getErrorCode() == 1) {
         msg = "Esiste già una ereditarietà con lo stesso codice";
         JOptionPane.showMessageDialog(this, msg, "Errore",
                 JOptionPane.ERROR_MESSAGE);
      } else {
         super.mostraErrori(e, query, contesto);
      }
   }
   
   /**
    * Metodo da usare nei form di lookup per passare i dati al form
    * chiamante.
    */
   @Override
   protected void premutoOK() {
      if (getPadre() != null) {
         getPadre().setProprieta("ereditare_entita_entita", getTCodice().getText());
         try {
            rs.close();
         } catch (SQLException e) {
            mostraErrori(e);
         }
         dispose();
      }
   }
   
   /**
    * Ricopia i dati della riga selezionata del JTable
    * sugli altri controlli della finestra.
    */
   @Override
   protected void mostraDati() {
      try {
         rs.previous(); rs.next();
         jComboBoxCardinalità.setSelectedItem(rs.getString("cardinalita"));
         jComboBoxTipo.setSelectedItem(rs.getString("tipo"));
         jComboBoxSuperclasse.setSelectedItem(rs.getString("superclasse"));
         super.mostraDati();
      } catch (SQLException e) {
//         mostraErrori(e);
      }
   }
   
   @Override
   protected void pulisci() {
      super.pulisci();
      jComboBoxCardinalità.setSelectedItem("NESSUNA");
      jComboBoxTipo.setSelectedItem("NESSUNA");
      jComboBoxSuperclasse.setSelectedItem("");
   }
   
   /**
    * Forma una query corrispondente ai dati inseriti nei
    * controlli della finestra.
    * 
    * @return query, come {@link PreparedStatement}
    */
   @Override
   protected PreparedStatement creaSelectStatement() {
      Connection con;
      PreparedStatement st;
      String codice, card, tipo, superc;
      Pattern pat;
      Matcher matc;
      int k = 1;
      super.creaSelectStatement();
      codice = getTCodice().getText();
      card = jComboBoxCardinalità.getSelectedItem().toString();
      tipo = jComboBoxTipo.getSelectedItem().toString();
      superc = jComboBoxSuperclasse.getSelectedItem().toString();

      query += " where";
      //}
      if (superc.length() > 0) {
         query += " superclasse= ? and";
      }
      if (codice.length() > 0) {
         query += " codice= ? and";
      }
      if (card.length() > 0 && !card.equals("NESSUNA")) {
         if (card.contains("%")) {
            query += " cardinalita like ? and";
         } else {
            query += " cardinalita = ? and";
         }
      }
      if (idEntità.length() > 0) {
         query += " sottoclasse = ? and";
      }
      if (tipo.length() > 0 && !tipo.equals("NESSUNA")) {
         if (tipo.contains("%")) {
            query += " tipo like ? and";
         } else {
            query += " tipo = ? and";
         }
      }
      pat = Pattern.compile("where$|and$"); //cancella where o and finali
      matc = pat.matcher(query);
      query = matc.replaceAll("");
      query += " order by codice";
      try {
         con = Database.getDefaultConnection();
         st = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);

         if(String.valueOf(mapEntità.get(superc)).length() > 0){
             st.setInt(k++, mapEntità.get(superc));
         }
         if (codice.length() > 0) {
            st.setInt(k++, Integer.decode(codice));
         }
         if (card.length() > 0 && !card.equals("NESSUNA")) {
            st.setString(k++, card);
         }
         if (idEntità.length() > 0) {
            st.setString(k++, idEntità);
         }
         if (tipo.length() > 0 && !tipo.equals("NESSUNA")) {
            st.setString(k++, tipo);
         }
         return st;
      } catch (SQLException e) {
         mostraErrori(e);
         return null;
      }
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEreditarietà = new javax.swing.JTable();
        jComboBoxSuperclasse = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBoxTipo = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jComboBoxCardinalità = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(500, 200));
        setSize(new java.awt.Dimension(500, 200));

        jTableEreditarietà.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableEreditarietà);

        jComboBoxSuperclasse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxSuperclasseActionPerformed(evt);
            }
        });

        jLabel1.setText("Superclasse");

        jLabel2.setText("Tipo");

        jComboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "DISGIUNTA", "UNIONE", "SOVRAPPOSTA" }));

        jLabel3.setText("Cardinalità");

        jComboBoxCardinalità.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "PARZIALE", "TOTALE" }));

        jButton1.setText("Indietro");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(24, 24, 24)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jComboBoxCardinalità, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBoxTipo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBoxSuperclasse, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                        .addComponent(jButton1)))
                .addContainerGap())
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBoxSuperclasse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBoxCardinalità, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        this.entità.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBoxSuperclasseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxSuperclasseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxSuperclasseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ereditarietà.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ereditarietà.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ereditarietà.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ereditarietà.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ereditarietà().setVisible(true);
            }
        });
    }
    
    protected void impostaCodice() {
   }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBoxCardinalità;
    private javax.swing.JComboBox<String> jComboBoxSuperclasse;
    private javax.swing.JComboBox<String> jComboBoxTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableEreditarietà;
    // End of variables declaration//GEN-END:variables

    @Override
   protected PreparedStatement getComandoInserimento(Connection c)
           throws SQLException {
      String cmdIns;
      PreparedStatement st;
      cmdIns = "insert into " + Database.schema + ".ereditare_entita_entita (codice, superclasse,sottoclasse,"
              + "cardinalita, tipo) values(?,?,?,?,?)";
      st = c.prepareStatement(cmdIns);
      st.setInt(1, 0);
      st.setString(2, String.valueOf(mapEntità.get(jComboBoxSuperclasse.getSelectedItem().toString())));
      st.setString(3, idEntità);
      st.setString(4, jComboBoxCardinalità.getSelectedItem().toString());
      st.setString(5, jComboBoxTipo.getSelectedItem().toString());
      return st;
   }

    @Override
   protected PreparedStatement getComandoAggiornamento(Connection c)
           throws SQLException {
      String cmdUp;
      PreparedStatement st;
      cmdUp = "update " + Database.schema + ".ereditare_entita_entita set superclasse=?, tipo=?, cardinalita=?"
              + "where codice=? and sottoclasse=?";
      st = c.prepareStatement(cmdUp);
      st.setString(1, String.valueOf(mapEntità.get(jComboBoxSuperclasse.getSelectedItem().toString())));
      st.setString(2, jComboBoxTipo.getSelectedItem().toString());
      st.setString(3, jComboBoxCardinalità.getSelectedItem().toString());
      st.setInt(4, Integer.decode(getTCodice().getText()));
      st.setString(5, String.valueOf(idEntità));
      return st;
   }

    private void addItemCombo(Map<String, Integer> res) {
        jComboBoxSuperclasse.removeAllItems();
        for(String en: res.keySet()){
            jComboBoxSuperclasse.addItem(en);
        }
    }
    
    private int getIdEntitàSuperclasse(){
        String value = jComboBoxSuperclasse.getSelectedItem().toString();
        return this.mapEntità.get(value);
    }
    
    protected void disposeCurrentPanel() {
        dispose();
    }
    
}
