/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unina.db2019;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author a
 */
public class Schema extends DBFrame {

    /**
     * Creates new form Schema
     */
    public Schema() {
        super();
        initComponents();
        setModalita(APPEND_QUERY);
        setFrameTable(jTableSchema);
        setNomeTabella("schema1");
        super.setColorTextField(jTextFieldNome);
        this.loginOrExit();
        setTitle("SCHEMA");
    }
    
    private void loginOrExit() {
      Login l = new Login(this, true);
      l.setVisible(true);
      if (l.getPremuto() == Login.PREMUTO_ANNULLA) {
         dispose();
      } else {
         setVisible(true);
      }
   }
    
    /**
    * Imposta lo stato corrente del form. <br> In base allo stato vengono
    * abilitati o disabilitati alcuni oggetti del form.
    * 
    * @param modo intero che rappresenta lo stato
    */
   @Override
   final public void setModalita(int modo) {
      super.setModalita(modo);
      switch (modo) {
         case APPEND_QUERY:
            jTextFieldNome.setEnabled(true);
            jTextFieldDescrizione.setEnabled(true);
            break;
         case BROWSE:
            jTextFieldNome.setEnabled(false);
            jTextFieldDescrizione.setEnabled(false);
            break;
         case UPDATE:
            jTextFieldNome.setEnabled(true);
            jTextFieldDescrizione.setEnabled(true);
            break;
      }
   }
   
   /**
    * Mostra una descrizione di un errore SQL in un linguaggio comprensibile per
    * l'utente finale.
    * 
    * @param e eccezione SQLException catturata
    * @param query l'istruzione SQL che ha causato l'errore
    * @param contesto intero per distinguere se l'eccezione ha avuto origine
    * da una query
    */
   @Override
   protected void mostraErrori(SQLException e, String query, int contesto) {
      String msg;
      if (e.getErrorCode() == 1) {
         msg = "Esiste già unoschema con lo stesso codice";
         JOptionPane.showMessageDialog(this, msg, "Errore",
                 JOptionPane.ERROR_MESSAGE);
      } else {
         super.mostraErrori(e, query, contesto);
      }
   }
   
   /**
    * Metodo da usare nei form di lookup per passare i dati al form
    * chiamante.
    */
   @Override
   protected void premutoOK() {
      if (getPadre() != null) {
         getPadre().setProprieta("Schema", getTCodice().getText());
         try {
            rs.close();
         } catch (SQLException e) {
            mostraErrori(e);
         }
         dispose();
      }
   }
   
   /**
    * Ricopia i dati della riga selezionata del JTable
    * sugli altri controlli della finestra.
    */
   @Override
   protected void mostraDati() {
      try {
         rs.previous(); rs.next();
         jTextFieldDescrizione.setText(rs.getString("descrizione"));
         jTextFieldNome.setText(rs.getString("nome_schema"));
         super.mostraDati();
      } catch (SQLException e) {
//         mostraErrori(e);
      }
   }
   
   /**
    * Cancella i dati presenti in tutti i controlli presenti sul form.
    */
   @Override
   protected void pulisci() {
      super.pulisci();
      jTextFieldDescrizione.setText("");
      jTextFieldNome.setText("");
   }
   
   /**
    * Forma una query corrispondente ai dati inseriti nei
    * controlli della finestra.
    * 
    * @return query, come {@link PreparedStatement}
    */
   @Override
   protected PreparedStatement creaSelectStatement() {
      Connection con;
      PreparedStatement st;
      String codice, descr, nome;
      Pattern pat;
      Matcher matc;
      int k = 1;
      super.creaSelectStatement();
      codice = getTCodice().getText();
      descr = jTextFieldDescrizione.getText();
      nome = jTextFieldNome.getText();

      query += " where";
      //}
      if (codice.length() > 0) {
         query += " codice= ? and";
      }
      if (descr.length() > 0) {
         if (descr.contains("%")) {
            query += " descrizione like ? and";
         } else {
            query += " descrizione = ? and";
         }
      }
      if (nome.length() > 0) {
         if (nome.contains("%")) {
            query += " nome_schema like ?";
         } else {
            query += " nome_schema = ?";
         }
      }
      pat = Pattern.compile("where$|and$"); //cancella where o and finali
      matc = pat.matcher(query);
      query = matc.replaceAll("");
      query += " order by codice";
      try {
         con = Database.getDefaultConnection();
         st = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);

         if (codice.length() > 0) {
            st.setInt(k++, Integer.decode(codice));
         }
         if (descr.length() > 0) {
            st.setString(k++, descr);
         }
         if (nome.length() > 0) {
            st.setString(k++, nome);
         }
         return st;
      } catch (SQLException e) {
         mostraErrori(e);
         return null;
      }
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableSchema = new javax.swing.JTable();
        jTextFieldNome = new javax.swing.JTextField();
        jTextFieldDescrizione = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButtonEntità = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestione Schemi");
        setLocation(new java.awt.Point(500, 200));

        jTableSchema.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableSchema);

        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });

        jTextFieldDescrizione.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldDescrizioneActionPerformed(evt);
            }
        });

        jLabel1.setText("Nome");

        jLabel2.setText("Descrizione");

        jButtonEntità.setText("Gestisci Entità");
        jButtonEntità.setMaximumSize(new java.awt.Dimension(100, 23));
        jButtonEntità.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEntitàActionPerformed(evt);
            }
        });

        jButton1.setText("Gestisci Relazioni");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldNome, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(jTextFieldDescrizione))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButtonEntità, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(24, 24, 24))
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(101, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jButtonEntità, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldDescrizione, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldDescrizioneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDescrizioneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldDescrizioneActionPerformed

    private void jButtonEntitàActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEntitàActionPerformed
        if(jTableSchema.getSelectedRow() < 0)
            JOptionPane.showMessageDialog(new JFrame(), "IMPOSSIBILE CLICCARE IL PULSANTE. SELEZIONARE UNO SCHEMA", "ERRORE",
        JOptionPane.ERROR_MESSAGE);
        int columnIdSchema = 0;
        int columnNomeSchema = 1;
        int row = jTableSchema.getSelectedRow();
        String idSchema = jTableSchema.getModel().getValueAt(row, columnIdSchema).toString();
        String nomeSchema = jTableSchema.getModel().getValueAt(row, columnNomeSchema).toString();
        this.setVisible(false);
        Entità e = new Entità(Integer.parseInt(idSchema), nomeSchema, this);
        e.setVisible(true);
    }//GEN-LAST:event_jButtonEntitàActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(jTableSchema.getSelectedRow() < 0)
            JOptionPane.showMessageDialog(new JFrame(), "IMPOSSIBILE CLICCARE IL PULSANTE. SELEZIONARE UNO SCHEMA", "ERRORE",
        JOptionPane.ERROR_MESSAGE);
        int columnIdSchema = 0;
        int columnNomeSchema = 1;
        int row = jTableSchema.getSelectedRow();
        String idSchema = jTableSchema.getModel().getValueAt(row, columnIdSchema).toString();
        String nomeSchema = jTableSchema.getModel().getValueAt(row, columnNomeSchema).toString();
        this.setVisible(false);
        Relazione r = new Relazione(Integer.parseInt(idSchema), nomeSchema, this);
        r.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldNomeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Schema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Schema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Schema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Schema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Schema().setVisible(true);
            }
        });
    }
    
    protected void impostaCodice() {
   }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonEntità;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableSchema;
    private javax.swing.JTextField jTextFieldDescrizione;
    private javax.swing.JTextField jTextFieldNome;
    // End of variables declaration//GEN-END:variables

    /**
    * Prepara il comando SQL di inserimento in base ai dati
    * inseriti nei controlli.
    * 
    * @param c la connessione al DB
    * @return il comando, come {@link PreparedStatement}
    * @throws SQLException in caso di errori nel preparare il
    * comando
    */
   @Override
   protected PreparedStatement getComandoInserimento(Connection c)
           throws SQLException {
      String cmdIns;
      PreparedStatement st;
      cmdIns = "insert into " + Database.schema + ".schema1 (codice,descrizione,"
              + "nome_schema) values(?,?,?)";
      st = c.prepareStatement(cmdIns);
      st.setInt(1, 0);
      st.setString(2, jTextFieldDescrizione.getText());
      st.setString(3, jTextFieldNome.getText());
      return st;
   }

    /**
    * Prepara il comando SQL di aggiornamento in base ai dati
    * inseriti nei controlli.
    * 
    * @param c la connessione al DB
    * @return il comando, come {@link PreparedStatement}
    * @throws SQLException in caso di errori nel preparare il
    * comando
    */
   @Override
   protected PreparedStatement getComandoAggiornamento(Connection c)
           throws SQLException {
      String cmdUp;
      PreparedStatement st;
      cmdUp = "update " + Database.schema + ".schema1 set descrizione=?,nome_Schema=? "
              + "where codice=?";
      st = c.prepareStatement(cmdUp);
      st.setString(1, jTextFieldDescrizione.getText());
      st.setString(2, jTextFieldNome.getText());
      st.setInt(3, Integer.decode(getTCodice().getText()));
      return st;
   }
   
   protected void disposeCurrentPanel() {
        dispose();
    }
}
