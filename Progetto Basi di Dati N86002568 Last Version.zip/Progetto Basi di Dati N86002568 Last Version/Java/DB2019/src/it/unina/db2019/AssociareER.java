/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unina.db2019;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author a
 */
public class AssociareER extends DBFrame {

    private int idSchema;
    private String nomeSchema;
    private Relazione relazione;
    private Map<String, Integer> mapEntità;
    private Map<String, Integer> mapRelazioni;
    private Map<String, Integer> mapAttributiEn1 = new HashMap<>();
    private Map<String, Integer> mapAttributiEn2 = new HashMap<>();

    /**
     * Creates new form AssociareER
     */
    public AssociareER() {
        initComponents();
    }

    AssociareER(int idSchema, String nomeSchema, Relazione relazione) {
        this.idSchema = idSchema;
        this.nomeSchema = nomeSchema;
        this.relazione = relazione;
        this.mapEntità = Database.getAllEntità(idSchema);
        this.mapRelazioni = Database.getAllRelazioniBySchema(idSchema);
        initComponents();
        setModalita(APPEND_QUERY);
        setFrameTable(jTableAssociareER);
        setNomeTabella("associare_entita_relazione"); // TODO: nome tabella
        setTitle(nomeSchema + ">" + "ASSOCIARE ER");
        this.initCombo();
        jComboBoxEn1.setBorder(new LineBorder(Color.RED));
        jComboBoxEn2.setBorder(new LineBorder(Color.RED));
        jComboBoxRelazioni.setBorder(new LineBorder(Color.RED));

        this.jComboBoxEn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (jComboBoxEn1.getSelectedItem().toString() != "NESSUNA") {
                    jComboBoxEn1.setBorder(new LineBorder(Color.WHITE));
                } else {
                    jComboBoxEn1.setBorder(new LineBorder(Color.RED));
                }
            }
        });

        this.jComboBoxEn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (jComboBoxEn2.getSelectedItem().toString() != "NESSUNA") {
                    jComboBoxEn2.setBorder(new LineBorder(Color.WHITE));
                } else {
                    jComboBoxEn2.setBorder(new LineBorder(Color.RED));
                }
            }
        });

        this.jComboBoxCard1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (jComboBoxCard1.getSelectedItem().toString() != "NESSUNA") {
                    jComboBoxCard1.setBorder(new LineBorder(Color.WHITE));
                } else {
                    jComboBoxCard1.setBorder(new LineBorder(Color.RED));
                }
            }
        });

        this.jComboBoxCard2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (jComboBoxCard2.getSelectedItem().toString() != "NESSUNA") {
                    jComboBoxCard2.setBorder(new LineBorder(Color.WHITE));
                } else {
                    jComboBoxCard2.setBorder(new LineBorder(Color.RED));
                }
            }
        });

        this.jComboBoxRelazioni.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (jComboBoxRelazioni.getSelectedItem().toString() != "NESSUNA") {
                    jComboBoxRelazioni.setBorder(new LineBorder(Color.WHITE));
                } else {
                    jComboBoxRelazioni.setBorder(new LineBorder(Color.RED));
                }
            }
        }); 
        
    }

    @Override
    final public void setModalita(int modo) {
        super.setModalita(modo);
        switch (modo) {
            case APPEND_QUERY:
                jComboBoxEn1.setEnabled(true);
                jComboBoxEn2.setEnabled(true);
//                jComboBoxCard1.setEnabled(true);
//                jComboBoxCard2.setEnabled(true);
//                jComboBoxAttr1En1.setEnabled(true);
//                jComboBoxAttr1En2.setEnabled(true);
//                jComboBoxAttr2En1.setEnabled(true);
//                jComboBoxAttr2En2.setEnabled(true);
//                jComboBoxRelazioni.setEnabled(true);
                break;
                
            case BROWSE:
                jComboBoxEn1.setEnabled(false);
                jComboBoxEn2.setEnabled(false);
                jComboBoxCard1.setEnabled(false);
                jComboBoxCard2.setEnabled(false);
                jComboBoxAttr1En1.setEnabled(false);
                jComboBoxAttr1En2.setEnabled(false);
                jComboBoxAttr2En2.setEnabled(false);
                jComboBoxAttr2En1.setEnabled(false);
                jComboBoxRelazioni.setEnabled(false);
                break;
                
            case UPDATE:
                jComboBoxEn1.setEnabled(true);
                jComboBoxEn2.setEnabled(true);
                jComboBoxCard1.setEnabled(true);
                jComboBoxCard2.setEnabled(true);
                if(!jComboBoxAttr1En1.getSelectedItem().toString().equals("NESSUNA"))
                    jComboBoxAttr1En1.setEnabled(true);
                if(!jComboBoxAttr1En2.getSelectedItem().toString().equals("NESSUNA"))
                    jComboBoxAttr1En2.setEnabled(true);
                if(!jComboBoxAttr2En2.getSelectedItem().toString().equals("NESSUNA"))
                    jComboBoxAttr2En2.setEnabled(true);
                if(!jComboBoxAttr2En1.getSelectedItem().toString().equals("NESSUNA"))
                    jComboBoxAttr2En1.setEnabled(true);
                jComboBoxRelazioni.setEnabled(true);
                break;
        }
    }

    @Override
    protected void mostraErrori(SQLException e, String query, int contesto) {
        String msg;
        if (e.getErrorCode() == 1) {
            msg = "Esiste già una associazione con lo stesso codice";
            JOptionPane.showMessageDialog(this, msg, "Errore",
                    JOptionPane.ERROR_MESSAGE);
        } else {
            super.mostraErrori(e, query, contesto);
        }
    }

    @Override
    protected void premutoOK() {
        if (getPadre() != null) {
            getPadre().setProprieta("associare_entita_relazione", getTCodice().getText());
            try {
                rs.close();
            } catch (SQLException e) {
                mostraErrori(e);
            }
            dispose();
        }
    }

    @Override
    protected void mostraDati() {
        try {
            rs.previous();
            rs.next();
            jComboBoxEn1.setSelectedItem(((ArrayList<String>) getKeysByValue(mapEntità, Integer.parseInt(rs.getString("id_ent1")))).get(0));
            jComboBoxEn2.setSelectedItem(((ArrayList<String>) getKeysByValue(mapEntità, Integer.parseInt(rs.getString("id_ent2")))).get(0));
            jComboBoxCard1.setSelectedItem(rs.getString("card1"));
            jComboBoxCard2.setSelectedItem(rs.getString("card2"));
            if(rs.getString("ID_ATTR1_EN1") != null)
                jComboBoxAttr1En1.setSelectedItem(((ArrayList<String>) getKeysByValue(mapAttributiEn1, Integer.parseInt(rs.getString("ID_ATTR1_EN1")))).get(0));        
            else
                jComboBoxAttr1En1.setSelectedItem("NESSUNA");
            
            if(rs.getString("ID_ATTR1_EN2") != null)
                jComboBoxAttr1En2.setSelectedItem(((ArrayList<String>) getKeysByValue(mapAttributiEn2, Integer.parseInt(rs.getString("ID_ATTR1_EN2")))).get(0));
            else
                jComboBoxAttr1En2.setSelectedItem("NESSUNA");
            
            if(rs.getString("ID_ATTR2_EN2") != null)
                jComboBoxAttr2En2.setSelectedItem(((ArrayList<String>) getKeysByValue(mapAttributiEn2, Integer.parseInt(rs.getString("ID_ATTR2_EN2")))).get(0));
            else
                jComboBoxAttr2En2.setSelectedItem("NESSUNA");
            
            if(rs.getString("ID_ATTR2_EN1") != null)
                jComboBoxAttr2En1.setSelectedItem(((ArrayList<String>) getKeysByValue(mapAttributiEn1, Integer.parseInt(rs.getString("ID_ATTR2_EN1")))).get(0));
            else
                jComboBoxAttr2En1.setSelectedItem("NESSUNA");
            
            jComboBoxRelazioni.setSelectedItem(((ArrayList<String>) getKeysByValue(mapRelazioni, Integer.parseInt(rs.getString("ID_REL")))).get(0));
            
            super.mostraDati();
        } catch (SQLException e) {
            e.printStackTrace();
//            mostraErrori(e);
        }
    }

    public <T, E> ArrayList<T> getKeysByValue(Map<T, E> map, E value) {
        ArrayList<T> keys = new ArrayList<T>();
        for (Entry<T, E> entry : map.entrySet()) {
            if (Objects.equals(value, entry.getValue())) {
                keys.add(entry.getKey());
            }
        }
        return keys;
    }

    @Override
    protected void pulisci() {
        super.pulisci();
        jComboBoxEn1.setSelectedItem("NESSUNA");
        jComboBoxEn2.setSelectedItem("NESSUNA");
        jComboBoxCard1.setSelectedItem("NESSUNA");
        jComboBoxCard2.setSelectedItem("NESSUNA");
        jComboBoxAttr1En1.setSelectedItem("NESSUNA");
        jComboBoxAttr1En2.setSelectedItem("NESSUNA");
        jComboBoxAttr2En2.setSelectedItem("NESSUNA");
        jComboBoxAttr2En1.setSelectedItem("NESSUNA");
        jComboBoxRelazioni.setSelectedItem("NESSUNA");
        jComboBoxEn1.setEnabled(true);
        jComboBoxEn2.setEnabled(true);
        jComboBoxCard1.setEnabled(false);
        jComboBoxCard2.setEnabled(false);
        jComboBoxAttr1En1.setEnabled(false);
        jComboBoxAttr1En2.setEnabled(false);
        jComboBoxAttr2En2.setEnabled(false);
        jComboBoxAttr2En1.setEnabled(false);
        jComboBoxRelazioni.setEnabled(true);
        
        
    }

    /**
     * Forma una query corrispondente ai dati inseriti nei controlli della
     * finestra.
     *
     * @return query, come {@link PreparedStatement}
     */
    @Override
    protected PreparedStatement creaSelectStatement() {
        Connection con;
        PreparedStatement st;
        String codice, card1, card2, ent1, ent2, rel, attr1, attr2, attr3, attr4;
        Pattern pat;
        Matcher matc;
        int k = 1;
        super.creaSelectStatement();
        codice = getTCodice().getText();
        card1 = jComboBoxCard1.getSelectedItem().toString();
        card2 = jComboBoxCard2.getSelectedItem().toString();
        ent1 = jComboBoxEn1.getSelectedItem().toString();
        ent2 = jComboBoxEn2.getSelectedItem().toString();
        rel = jComboBoxRelazioni.getSelectedItem().toString();
        attr1 = jComboBoxAttr1En1.getSelectedItem().toString();
        attr2 = jComboBoxAttr2En1.getSelectedItem().toString();
        attr3 = jComboBoxAttr1En2.getSelectedItem().toString();
        attr4 = jComboBoxAttr2En2.getSelectedItem().toString();

        query += " where";
        //}
        if (codice.length() > 0) {
            query += " codice = ? and";
        }

        if (card1.length() > 0 && !card1.equals("NESSUNA")) {
            if (card1.contains("%")) {
                query += " card1 like ? and";
            } else {
                query += " card1 = ? and";
            }
        }
        if (card2.length() > 0 && !card2.equals("NESSUNA")) {
            if (card2.contains("%")) {
                query += " card2 like ? and";
            } else {
                query += " card2 = ? and";
            }
        }
        if (ent1.length() > 0 && !ent1.equals("NESSUNA")) {
            query += " id_ent1 = ? and";
        }

        if (ent2.length() > 0 && !ent2.equals("NESSUNA")) {
            query += " id_ent2 = ? and";
        }

        if (rel.length() > 0 && !rel.equals("NESSUNA")) {
            query += " id_rel = ? and";
        }
        if (attr1.length() > 0 && !attr1.equals("NESSUNA")) {
            query += " id_attr1_en1 = ? and";
        }
        if (attr2.length() > 0 && !attr2.equals("NESSUNA")) {
            query += " id_attr2_en1 = ? and";
        }
        if (attr3.length() > 0 && !attr3.equals("NESSUNA")) {
            query += " id_attr1_en2 = ? and";
        }
        if (attr4.length() > 0 && !attr4.equals("NESSUNA")) {
            query += " id_attr2_en2 = ? and";
        }

        pat = Pattern.compile("where$|and$"); //cancella where o and finali
        matc = pat.matcher(query);
        query = matc.replaceAll("");
        query += " order by codice";
        try {
            con = Database.getDefaultConnection();
            st = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            if (codice.length() > 0) {
                st.setInt(k++, Integer.decode(codice));
            }
            if (card1.length() > 0 && !card1.equals("NESSUNA")) {
                st.setString(k++, card1);
            }
            if (card2.length() > 0 && !card2.equals("NESSUNA")) {
                st.setString(k++, card2);
            }
            if (String.valueOf(mapEntità.get(ent1)).length() > 0 && !ent1.equals("NESSUNA")) {
                st.setInt(k++, mapEntità.get(ent1));
            }
            if (String.valueOf(mapEntità.get(ent2)).length() > 0 && !ent2.equals("NESSUNA")) {
                st.setInt(k++, mapEntità.get(ent2));
            }
            if (String.valueOf(mapRelazioni.get(rel)).length() > 0 && !rel.equals("NESSUNA")) {
                st.setInt(k++, mapRelazioni.get(rel));
            }
            if (String.valueOf(mapAttributiEn1.get(attr1)).length() > 0 && !attr1.equals("NESSUNA")) {
                st.setInt(k++, mapAttributiEn1.get(attr1));
            }
            if (String.valueOf(mapAttributiEn1.get(attr2)).length() > 0 && !attr2.equals("NESSUNA")) {
                st.setInt(k++, mapAttributiEn1.get(attr2));
            }
            if (String.valueOf(mapAttributiEn2.get(attr3)).length() > 0 && !attr3.equals("NESSUNA")) {
                st.setInt(k++, mapAttributiEn2.get(attr3));
            }
            if (String.valueOf(mapAttributiEn2.get(attr4)).length() > 0 && !attr4.equals("NESSUNA")) {
                st.setInt(k++, mapAttributiEn2.get(attr4));
            }
            return st;
        } catch (SQLException e) {
            mostraErrori(e);
            return null;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBoxEn1 = new javax.swing.JComboBox<>();
        jComboBoxCard1 = new javax.swing.JComboBox<>();
        jComboBoxRelazioni = new javax.swing.JComboBox<>();
        jComboBoxCard2 = new javax.swing.JComboBox<>();
        jComboBoxEn2 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jComboBoxAttr1En1 = new javax.swing.JComboBox<>();
        jComboBoxAttr2En2 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBoxAttr1En2 = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jComboBoxAttr2En1 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableAssociareER = new javax.swing.JTable();
        jButtonIndietro = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(500, 200));

        jComboBoxEn1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxEn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxEn1ActionPerformed(evt);
            }
        });

        jComboBoxCard1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "0...1", "1", "1...*", "0...*" }));
        jComboBoxCard1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCard1ActionPerformed(evt);
            }
        });

        jComboBoxRelazioni.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxRelazioni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxRelazioniActionPerformed(evt);
            }
        });

        jComboBoxCard2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA", "0...1", "1", "1...*", "0...*" }));
        jComboBoxCard2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCard2ActionPerformed(evt);
            }
        });

        jComboBoxEn2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxEn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxEn2ActionPerformed(evt);
            }
        });

        jLabel1.setText("1a Entità");

        jLabel2.setText("1a Cardinalità");

        jLabel3.setText("Relazione");

        jLabel4.setText("2a Cardinalità");

        jLabel5.setText("2a Entità");

        jComboBoxAttr1En1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA" }));
        jComboBoxAttr1En1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxAttr1En1ActionPerformed(evt);
            }
        });

        jComboBoxAttr2En2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA" }));

        jLabel6.setText("SI RIFERISCE A");

        jLabel7.setText("Attibuti 2a Entità");

        jLabel8.setText("Attributi 1a Entità");

        jComboBoxAttr1En2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA" }));
        jComboBoxAttr1En2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxAttr1En2ActionPerformed(evt);
            }
        });

        jLabel9.setText("SI RIFERISCE A");

        jComboBoxAttr2En1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NESSUNA" }));

        jLabel10.setText("Attributi 1a Entità");

        jLabel11.setText("Attributi 2a Entità");

        jTableAssociareER.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableAssociareER);

        jButtonIndietro.setText("Indietro");
        jButtonIndietro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonIndietroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 489, Short.MAX_VALUE)
                        .addGap(21, 21, 21))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5)
                            .addComponent(jLabel1)
                            .addComponent(jComboBoxEn1, 0, 127, Short.MAX_VALUE)
                            .addComponent(jComboBoxEn2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBoxCard2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxCard1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))
                        .addGap(96, 96, 96)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(53, 53, 53))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButtonIndietro)
                                    .addComponent(jComboBoxRelazioni, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(33, 33, 33))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jComboBoxAttr2En1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxAttr2En2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9))
                        .addGap(84, 84, 84)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jComboBoxAttr1En1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxAttr1En2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel10)
                        .addGap(48, 48, 48))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(95, Short.MAX_VALUE)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jButtonIndietro))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxEn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel5)
                                .addGap(7, 7, 7)
                                .addComponent(jComboBoxEn2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxRelazioni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxCard1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxCard2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(29, 29, 29)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jComboBoxAttr1En1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxAttr2En2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jComboBoxAttr1En2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxAttr2En1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(jLabel10)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxEn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxEn2ActionPerformed

    }//GEN-LAST:event_jComboBoxEn2ActionPerformed

    private void jButtonIndietroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonIndietroActionPerformed
        this.relazione.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButtonIndietroActionPerformed

    private void jComboBoxAttr1En1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxAttr1En1ActionPerformed

    }//GEN-LAST:event_jComboBoxAttr1En1ActionPerformed

    private void jComboBoxCard2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCard2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCard2ActionPerformed

    private void jComboBoxCard1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCard1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCard1ActionPerformed

    private void jComboBoxRelazioniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxRelazioniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxRelazioniActionPerformed

    private void jComboBoxEn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxEn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxEn1ActionPerformed

    private void jComboBoxAttr1En2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxAttr1En2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxAttr1En2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AssociareER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AssociareER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AssociareER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AssociareER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AssociareER().setVisible(true);
            }
        });
    }

    protected void impostaCodice() {
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonIndietro;
    private javax.swing.JComboBox<String> jComboBoxAttr1En1;
    private javax.swing.JComboBox<String> jComboBoxAttr1En2;
    private javax.swing.JComboBox<String> jComboBoxAttr2En1;
    private javax.swing.JComboBox<String> jComboBoxAttr2En2;
    private javax.swing.JComboBox<String> jComboBoxCard1;
    private javax.swing.JComboBox<String> jComboBoxCard2;
    private javax.swing.JComboBox<String> jComboBoxEn1;
    private javax.swing.JComboBox<String> jComboBoxEn2;
    private javax.swing.JComboBox<String> jComboBoxRelazioni;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTableAssociareER;
    // End of variables declaration//GEN-END:variables

    @Override
    protected PreparedStatement getComandoInserimento(Connection c)
            throws SQLException {
        String cmdIns;
        PreparedStatement st;
        cmdIns = "insert into " + Database.schema + ".associare_entita_relazione (codice, id_ent1,"
                + "card1, id_rel, id_ent2, card2, id_attr1_en1, "
                + "id_attr2_en1, id_attr1_en2, id_attr2_en2) values(?,?,?,?,?,?,?,?,?,?)";

        st = c.prepareStatement(cmdIns);
        st.setInt(1, 0);
        st.setInt(2, mapEntità.get(jComboBoxEn1.getSelectedItem()));
        st.setString(3, jComboBoxCard1.getSelectedItem().toString());
        st.setInt(4, mapRelazioni.get(jComboBoxRelazioni.getSelectedItem()));
        st.setInt(5, mapEntità.get(jComboBoxEn2.getSelectedItem()));
        st.setString(6, jComboBoxCard2.getSelectedItem().toString());
        if (jComboBoxAttr1En1.isEnabled() && !jComboBoxAttr1En1.getSelectedItem().equals("NESSUNA")) {
            st.setInt(7, mapAttributiEn1.get(jComboBoxAttr1En1.getSelectedItem()));
        } else {
            st.setNull(7, java.sql.Types.INTEGER);
        }
        if (jComboBoxAttr2En1.isEnabled() && !jComboBoxAttr2En1.getSelectedItem().equals("NESSUNA")) {
            st.setInt(8, mapAttributiEn1.get(jComboBoxAttr2En1.getSelectedItem()));
        } else {
            st.setNull(8, java.sql.Types.INTEGER);
        }
        if (jComboBoxAttr1En2.isEnabled() && !jComboBoxAttr1En2.getSelectedItem().equals("NESSUNA")) {
            st.setInt(9, mapAttributiEn2.get(jComboBoxAttr1En2.getSelectedItem()));
        } else {
            st.setNull(9, java.sql.Types.INTEGER);
        }
        if (jComboBoxAttr2En2.isEnabled() && !jComboBoxAttr2En2.getSelectedItem().equals("NESSUNA")) {
            st.setInt(10, mapAttributiEn2.get(jComboBoxAttr2En2.getSelectedItem()));
        } else {
            st.setNull(10, java.sql.Types.INTEGER);
        }
        return st;
    }

    @Override
    protected PreparedStatement getComandoAggiornamento(Connection c)
            throws SQLException {
        String cmdUp;
        PreparedStatement st;
        cmdUp = "update " + Database.schema + ".associare_entita_relazione set id_ent1=?, card1=?, "
                + "id_rel=?, id_ent2=?, card2=?, id_attr1_en1=?, "
                + "id_attr2_en1=? , id_attr1_en2=?, id_attr2_en2=?"
                + "where codice=?";
        st = c.prepareStatement(cmdUp);
        st.setString(1, String.valueOf(mapEntità.get(jComboBoxEn1.getSelectedItem().toString())));
        st.setString(2, String.valueOf(jComboBoxCard1.getSelectedItem().toString()));
        st.setString(3, String.valueOf(mapRelazioni.get(jComboBoxRelazioni.getSelectedItem().toString())));
        st.setString(4, String.valueOf(mapEntità.get(jComboBoxEn2.getSelectedItem().toString())));
        st.setString(5, String.valueOf(jComboBoxCard2.getSelectedItem().toString()));
        
        if (jComboBoxAttr1En1.isEnabled() && !jComboBoxAttr1En1.getSelectedItem().equals("NESSUNA")) {
            st.setString(6, String.valueOf(mapAttributiEn1.get(jComboBoxAttr1En1.getSelectedItem().toString())));
        }else {
            st.setNull(6, java.sql.Types.INTEGER);
        }
        
        if (jComboBoxAttr2En1.isEnabled() && !jComboBoxAttr2En1.getSelectedItem().equals("NESSUNA")) {
            st.setString(7, String.valueOf(mapAttributiEn1.get(jComboBoxAttr2En1.getSelectedItem().toString())));
        }else {
            st.setNull(7, java.sql.Types.INTEGER);
        }
        
        if (jComboBoxAttr1En2.isEnabled() && !jComboBoxAttr1En2.getSelectedItem().equals("NESSUNA")) {
            st.setString(8, String.valueOf(mapAttributiEn2.get(jComboBoxAttr1En2.getSelectedItem().toString())));
        }else {
            st.setNull(8, java.sql.Types.INTEGER);
        }
        
        if (jComboBoxAttr2En2.isEnabled() && !jComboBoxAttr2En2.getSelectedItem().equals("NESSUNA")) {
            st.setString(9, String.valueOf(mapAttributiEn2.get(jComboBoxAttr2En2.getSelectedItem().toString())));
        }else {
            st.setNull(9, java.sql.Types.INTEGER);
        }
        st.setInt(10, Integer.decode(getTCodice().getText()));
        return st;
    }

    private void addListenersCombobox() {
        this.addListenerEn1();
        this.addListenerEn2();
        this.addListenerAttributi2Entità1();
        this.addListenerAttributi2Entità2();
        this.addListenerCard1();
        this.addListenerCard2();
    }

    private void addListenerEn1() {
        jComboBoxEn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (!jComboBoxEn1.getSelectedItem().equals("NESSUNA")) {
                    jComboBoxCard1.setEnabled(true);
                    jComboBoxCard1.setBorder(new LineBorder(Color.RED));
                } else {
                    jComboBoxCard1.setSelectedItem("NESSUNA");
                    jComboBoxCard1.setEnabled(false);
                    jComboBoxCard1.setBorder(new LineBorder(Color.WHITE));
                }

                mapAttributiEn1 = Database.getAttributeByEntità(mapEntità.get(jComboBoxEn1.getSelectedItem()));
                riempiCombo(jComboBoxAttr1En1, mapAttributiEn1);
                riempiCombo(jComboBoxAttr2En1, mapAttributiEn1);
            }
        });
    }

    private void addListenerEn2() {
        jComboBoxEn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (!jComboBoxEn2.getSelectedItem().equals("NESSUNA")) {
                    jComboBoxCard2.setEnabled(true);
                    jComboBoxCard2.setBorder(new LineBorder(Color.RED));
                } else {
                    jComboBoxCard2.setSelectedItem("NESSUNA");
                    jComboBoxCard2.setEnabled(false);
                    jComboBoxCard2.setBorder(new LineBorder(Color.WHITE));
                }

                mapAttributiEn2 = Database.getAttributeByEntità(mapEntità.get(jComboBoxEn2.getSelectedItem()));

                riempiCombo(jComboBoxAttr1En2, mapAttributiEn2);
                riempiCombo(jComboBoxAttr2En2, mapAttributiEn2);
            }
        });
    }

    private void addListenerAttributi2Entità1() {
        jComboBoxAttr2En2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("Ho selezionato la terza combo");
            }
        });
    }

    private void addListenerAttributi2Entità2() {
        jComboBoxAttr2En1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("Ho selezionato la quarta combo");
            }
        });
    }

    private void initCombo() {
        this.jComboBoxCard1.setEnabled(false);
        this.jComboBoxCard2.setEnabled(false);
        this.jComboBoxAttr1En1.setEnabled(false);
        this.jComboBoxAttr1En2.setEnabled(false);
        this.jComboBoxAttr2En2.setEnabled(false);
        this.jComboBoxAttr2En1.setEnabled(false);
        this.riempiCombo(jComboBoxEn1, this.mapEntità);
        this.riempiCombo(jComboBoxEn2, this.mapEntità);
        this.riempiCombo(jComboBoxRelazioni, this.mapRelazioni);
        this.addListenersCombobox();
    }

    private void riempiCombo(JComboBox<String> jComboBox, Map<String, Integer> allEntità) {
        jComboBox.removeAllItems();
        jComboBox.addItem("NESSUNA");
        for (String en : allEntità.keySet()) {
            jComboBox.addItem(en);
        }
        jComboBox.setSelectedItem("NESSUNA");
    }

    private void addListenerCard1() {
        jComboBoxCard1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                combinazioniCardinalità();
            }
        });
    }

    private void combinazioniCardinalità() {
        if (jComboBoxCard1.getSelectedItem().equals("NESSUNA") || jComboBoxCard2.getSelectedItem().equals("NESSUNA")) {
            this.jComboBoxAttr1En1.setSelectedItem("NESSUNA");
            this.jComboBoxAttr1En1.setEnabled(false);
            jComboBoxAttr1En1.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr1En2.setSelectedItem("NESSUNA");
            this.jComboBoxAttr1En2.setEnabled(false);
            jComboBoxAttr1En2.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr2En2.setSelectedItem("NESSUNA");
            this.jComboBoxAttr2En2.setEnabled(false);
            jComboBoxAttr2En2.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr2En1.setSelectedItem("NESSUNA");
            this.jComboBoxAttr2En1.setEnabled(false);
            jComboBoxAttr2En1.setBorder(new LineBorder(Color.white));
        } else if ((jComboBoxCard1.getSelectedItem().equals("0...1") && jComboBoxCard2.getSelectedItem().equals("0...1"))
                || (jComboBoxCard1.getSelectedItem().equals("0...1") && jComboBoxCard2.getSelectedItem().equals("1"))
                || (jComboBoxCard1.getSelectedItem().equals("1") && jComboBoxCard2.getSelectedItem().equals("0...1"))
                || (jComboBoxCard1.getSelectedItem().equals("1") && jComboBoxCard2.getSelectedItem().equals("1"))) {
            this.jComboBoxAttr1En1.setEnabled(true);
            jComboBoxAttr1En1.setBorder(new LineBorder(Color.RED));
            this.jComboBoxAttr1En2.setEnabled(true);
            jComboBoxAttr1En2.setBorder(new LineBorder(Color.RED));
            this.jComboBoxAttr2En2.setEnabled(true);
            jComboBoxAttr2En2.setBorder(new LineBorder(Color.RED));
            this.jComboBoxAttr2En1.setEnabled(true);
            jComboBoxAttr2En1.setBorder(new LineBorder(Color.RED));
        } else if ((jComboBoxCard1.getSelectedItem().equals("1...*") && jComboBoxCard2.getSelectedItem().equals("1...*"))
                || (jComboBoxCard1.getSelectedItem().equals("0...*") && jComboBoxCard2.getSelectedItem().equals("1...*"))
                || (jComboBoxCard1.getSelectedItem().equals("0...*") && jComboBoxCard2.getSelectedItem().equals("0...*"))
                || (jComboBoxCard1.getSelectedItem().equals("1...*") && jComboBoxCard2.getSelectedItem().equals("0...*"))) {
            this.jComboBoxAttr1En1.setSelectedItem("NESSUNA");
            this.jComboBoxAttr1En1.setEnabled(false);
            jComboBoxAttr1En1.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr1En2.setSelectedItem("NESSUNA");
            this.jComboBoxAttr1En2.setEnabled(false);
            jComboBoxAttr1En2.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr2En2.setSelectedItem("NESSUNA");
            this.jComboBoxAttr2En2.setEnabled(false);
            jComboBoxAttr2En2.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr2En1.setSelectedItem("NESSUNA");
            this.jComboBoxAttr2En1.setEnabled(false);
            jComboBoxAttr2En1.setBorder(new LineBorder(Color.white));
        } else if ((jComboBoxCard1.getSelectedItem().equals("1") && jComboBoxCard2.getSelectedItem().equals("1...*"))
                || (jComboBoxCard1.getSelectedItem().equals("1") && jComboBoxCard2.getSelectedItem().equals("0...*"))
                || (jComboBoxCard1.getSelectedItem().equals("0...1") && jComboBoxCard2.getSelectedItem().equals("0...*"))
                || (jComboBoxCard1.getSelectedItem().equals("0...1") && jComboBoxCard2.getSelectedItem().equals("1...*"))) {
            this.jComboBoxAttr1En1.setEnabled(true);
            jComboBoxAttr1En1.setBorder(new LineBorder(Color.red));
            this.jComboBoxAttr1En2.setSelectedItem("NESSUNA");
            this.jComboBoxAttr1En2.setEnabled(false);
            jComboBoxAttr1En2.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr2En2.setEnabled(true);
            jComboBoxAttr2En2.setBorder(new LineBorder(Color.red));
            this.jComboBoxAttr2En1.setSelectedItem("NESSUNA");
            this.jComboBoxAttr2En1.setEnabled(false);
            jComboBoxAttr2En1.setBorder(new LineBorder(Color.white));
        } else if ((jComboBoxCard1.getSelectedItem().equals("1...*") && jComboBoxCard2.getSelectedItem().equals("1"))
                || (jComboBoxCard1.getSelectedItem().equals("0...*") && jComboBoxCard2.getSelectedItem().equals("1"))
                || (jComboBoxCard1.getSelectedItem().equals("0...*") && jComboBoxCard2.getSelectedItem().equals("0...1"))
                || (jComboBoxCard1.getSelectedItem().equals("1...*") && jComboBoxCard2.getSelectedItem().equals("0...1"))) {
            this.jComboBoxAttr1En1.setSelectedItem("NESSUNA");
            this.jComboBoxAttr1En1.setEnabled(false);
            jComboBoxAttr1En1.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr1En2.setEnabled(true);
            jComboBoxAttr1En2.setBorder(new LineBorder(Color.red));
            this.jComboBoxAttr2En2.setSelectedItem("NESSUNA");
            this.jComboBoxAttr2En2.setEnabled(false);
            jComboBoxAttr2En2.setBorder(new LineBorder(Color.white));
            this.jComboBoxAttr2En1.setEnabled(true);
            jComboBoxAttr2En1.setBorder(new LineBorder(Color.red));
        }
    }

    private void addListenerCard2() {
        jComboBoxCard2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                combinazioniCardinalità();
            }
        });
    }

    protected void disposeCurrentPanel() {
        dispose();
    }
}
