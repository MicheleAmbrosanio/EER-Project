CREATE TABLE  "MARCA" 
   (	"CODICE" NUMBER, 
	"DESCRIZIONE" VARCHAR2(255), 
	"SEDE" VARCHAR2(50), 
	 CONSTRAINT "MARCA_PK" PRIMARY KEY ("CODICE") ENABLE
   );
/
CREATE TABLE  "MODELLO" 
   (	"CODICE" NUMBER, 
	"MARCACODICE" NUMBER, 
	"DESCRIZIONE" VARCHAR2(255), 
	"DAPERIODO" DATE, 
	"APERIODO" DATE, 
	 CONSTRAINT "MODELLO_PK" PRIMARY KEY ("CODICE") ENABLE, 
	 CONSTRAINT "MODELLO_CON" FOREIGN KEY ("MARCACODICE")
	  REFERENCES  "MARCA" ("CODICE") ENABLE
   );
/

CREATE OR REPLACE FORCE VIEW  "VMODELLO" ("CODICE", "MARCA", "DESCRIZIONE", "DAPERIODO", "APERIODO", "MARCACODICE") AS 
  select modello.codice,marca.descrizione as marca,modello.descrizione,DaPeriodo,APeriodo,marcacodice from modello inner join marca on marca.codice=marcacodice;
/

insert into MARCA values (1,'Fiat','Torino');
insert into MODELLO(CODICE,MARCACODICE,DESCRIZIONE,DAPERIODO) values (1,1,'500',to_date('04/07/2007','DD/MM/YYYY'));
commit;
/* inserire trigger, procedure ecc. */
